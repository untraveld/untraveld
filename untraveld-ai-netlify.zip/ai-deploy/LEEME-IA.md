# untraveld — IA de itinerarios (Haiku) · Guía de despliegue

Esto añade a la app un botón **"Generar con IA ✨"** y un **ajuste conversacional**
en el detalle de cada día. La app llama a una pequeña función en tu propio
Netlify, y esa función es la que habla con la IA (Claude Haiku) usando tu clave,
que **nunca** viaja al móvil ni aparece en el HTML.

## Qué contiene este paquete

```
index.html                         ← la app (renombra aquí tu untraveld-espana-beta.html)
netlify.toml                       ← config de Netlify (publica la web + la función)
netlify/functions/ai-itinerary.js  ← el backend que llama a Haiku
```

## Pasos (una sola vez)

### 1) Consigue una clave de API de Anthropic
1. Entra en **console.anthropic.com** → crea una cuenta si no la tienes.
2. Añade un poco de saldo en **Billing** (con 5 $ te sobra para muchísimas pruebas).
3. En **API Keys** → **Create Key** → copia la clave (empieza por `sk-ant-...`).
   Guárdala; no se vuelve a mostrar.

### 2) Prepara la carpeta
- Copia tu HTML actual dentro de esta carpeta y renómbralo **`index.html`**.
  (El HTML ya viene preparado para llamar a `/.netlify/functions/ai-itinerary`.)

### 3) Despliega en Netlify **con la función**
La forma más sencilla, manteniendo tu sitio actual:
1. En **app.netlify.com**, entra en tu sitio (el de `utdmurciateam` o el que uses).
2. Pestaña **Deploys** → arrastra **toda esta carpeta** a la zona de "Drag and drop".
   (Es importante arrastrar la carpeta entera, no solo el HTML, para que suba
   también `netlify.toml` y la carpeta `netlify/functions`.)
3. Netlify detectará la función automáticamente.

### 4) Pon la clave como variable de entorno
1. En tu sitio de Netlify → **Site configuration → Environment variables**.
2. **Add a variable**:
   - Key: `ANTHROPIC_API_KEY`  ·  Value: tu clave `sk-ant-...`
   - (opcional) `CLAUDE_MODEL` = `claude-haiku-4-5`
   - (opcional) `AI_DAILY_LIMIT` = `50`  (tope de generaciones por persona y día,
     como red de seguridad para que nadie dispare tu factura).
3. Vuelve a **Deploys → Trigger deploy → Deploy site** para que la función tome la clave.

### 5) Prueba
Abre la app, ve a **Itinerario → Plan**, rellena fechas/perfil y pulsa
**"Generar con IA ✨"**. Entra en un día y prueba el cuadro **"Ajustar con IA"**
(p. ej. *"hoy llueve, ponme planes de interior"*).

## Notas importantes

- **No rompe nada de lo actual.** El botón clásico "Crear mi agenda" sigue igual.
  Si la función no está desplegada o falla, la app avisa con un mensaje y el resto
  sigue funcionando. Los amigos que usen el despliegue sin función no notan cambios.
- **La IA solo elige de tus puntos curados** (no inventa lugares), así que tus
  logros e insignias siguen bajo control.
- **Coste**: con Haiku, cada itinerario cuesta ~2 céntimos. Puedes limitarlo con
  `AI_DAILY_LIMIT`.
- Si la API respondiera con un error de modelo, revisa que `CLAUDE_MODEL` sea un id
  válido en tu cuenta (por ejemplo `claude-haiku-4-5` o `claude-haiku-4-5-20251001`).
- El endpoint por defecto es `/.netlify/functions/ai-itinerary`. Si algún día lo
  alojas en otro sitio, puedes fijarlo desde la consola del navegador con:
  `localStorage.setItem('utd-ai-endpoint','https://tu-dominio/tu-funcion')`.
