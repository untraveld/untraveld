# untraveld — paquete listo para GitHub

Repo: `untraveld/untraveld` · rama `main` · Netlify publica desde la raíz (`publish = "."`).

**Tu `index.html` ya viene retocado y colocado en `app/`. No hay que editar nada a mano.**

## Contenido

```
index.html                 landing
_redirects                 /untraveld-app → /app/
favicon.png
apple-touch-icon.png
app/
  index.html               TU app, con dos cambios ya aplicados (ver abajo)
  manifest.webmanifest     start_url y scope en /app/
  sw.js                    service worker, ámbito /app/
  icon-192.png
  icon-512.png
  icon-maskable-512.png
  apple-touch-icon.png
```

## Qué se cambió dentro de tu app

Solo dos líneas, de rutas relativas a absolutas, para que funcione desde `/app/`:

1. `<link rel="manifest" href="manifest.webmanifest">`
   → `<link rel="manifest" href="/app/manifest.webmanifest">`
2. `navigator.serviceWorker.register("sw.js")`
   → `navigator.serviceWorker.register("/app/sw.js",{scope:"/app/"})`

Nada más. El resto del archivo está intacto, incluido tu apple-touch-icon en base64.

## Cómo subirlo

1. En el repo, **borra el `index.html` de la raíz** (el de la app).
2. Sube todo el contenido de este paquete respetando las carpetas.
3. Commit. Netlify redespliega solo.

`netlify/functions/` y `netlify.toml` no se tocan.

## Comprobado antes de empaquetar

- `/` sirve la landing y su botón apunta a `/app/`
- `/app/` sirve la app y su manifest resuelve a `/app/manifest.webmanifest`
- `/app/manifest.webmanifest` responde 200 y es JSON válido
- `sw.js` pasa la comprobación de sintaxis

## Al publicar cambios de la app

Sube el número de `VERSION` en `app/sw.js` (`utd-v1` → `utd-v2`, …).
Si no, quien la tenga instalada seguirá viendo la versión cacheada.

## Pendiente, y es lo más urgente

El repo es público y las reglas de Firebase siguen abiertas: cualquiera puede
leer la configuración y entrar en la base de datos. Ponerlo privado ayuda,
pero lo que lo arregla son las reglas de seguridad.
